using System.Data;

namespace V1_Калькулятор
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ClickB(object sender, EventArgs e)
        {
            var currentButton = sender as Button;
            textBox1.Text += currentButton.Text;

        }

        private void button17_Click(object sender, EventArgs e)
        {
            var str = "";
            for (int i = 0; i < textBox1.Text.Length - 1; i++)
            {
                str += textBox1.Text[i];
            }
            textBox1.Text = str;

        }

        private void button16_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            var D = new DataTable();
            textBox1.Text = D.Compute(textBox1.Text, " ").ToString();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ButtonTan(object sender, EventArgs e)
        {

        }

        private void ButtonCoTan(object sender, EventArgs e)
        {
        }

        private void ButtonSin(object sender, EventArgs e)
        {

        }

        private void ButtonCos(object sender, EventArgs e)
        {

        }
    }
}
