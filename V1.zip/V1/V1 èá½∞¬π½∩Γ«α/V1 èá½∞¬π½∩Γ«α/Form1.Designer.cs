﻿namespace V1_Калькулятор
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button11 = new Button();
            button17 = new Button();
            label1 = new Label();
            button18 = new Button();
            button19 = new Button();
            button21 = new Button();
            button22 = new Button();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Menu;
            textBox1.Font = new Font("Segoe UI", 25F);
            textBox1.Location = new Point(38, 12);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(264, 52);
            textBox1.TabIndex = 0;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // button1
            // 
            button1.BackColor = Color.LightGray;
            button1.Location = new Point(38, 84);
            button1.Name = "button1";
            button1.Size = new Size(75, 73);
            button1.TabIndex = 1;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = false;
            button1.Click += ClickB;
            // 
            // button2
            // 
            button2.BackColor = Color.LightGray;
            button2.Location = new Point(133, 84);
            button2.Name = "button2";
            button2.Size = new Size(75, 73);
            button2.TabIndex = 2;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = false;
            button2.Click += ClickB;
            // 
            // button3
            // 
            button3.BackColor = Color.LightGray;
            button3.Location = new Point(227, 84);
            button3.Name = "button3";
            button3.Size = new Size(75, 73);
            button3.TabIndex = 3;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = false;
            button3.Click += ClickB;
            // 
            // button4
            // 
            button4.BackColor = Color.LightGray;
            button4.Location = new Point(227, 173);
            button4.Name = "button4";
            button4.Size = new Size(75, 73);
            button4.TabIndex = 6;
            button4.Text = "6";
            button4.UseVisualStyleBackColor = false;
            button4.Click += ClickB;
            // 
            // button5
            // 
            button5.BackColor = Color.LightGray;
            button5.Location = new Point(133, 173);
            button5.Name = "button5";
            button5.Size = new Size(75, 73);
            button5.TabIndex = 5;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = false;
            button5.Click += ClickB;
            // 
            // button6
            // 
            button6.BackColor = Color.LightGray;
            button6.Location = new Point(38, 173);
            button6.Name = "button6";
            button6.Size = new Size(75, 73);
            button6.TabIndex = 4;
            button6.Text = "4";
            button6.UseVisualStyleBackColor = false;
            button6.Click += ClickB;
            // 
            // button7
            // 
            button7.BackColor = Color.LightGray;
            button7.Location = new Point(227, 263);
            button7.Name = "button7";
            button7.Size = new Size(75, 73);
            button7.TabIndex = 9;
            button7.Text = "9";
            button7.UseVisualStyleBackColor = false;
            button7.Click += ClickB;
            // 
            // button8
            // 
            button8.BackColor = Color.LightGray;
            button8.Location = new Point(133, 263);
            button8.Name = "button8";
            button8.Size = new Size(75, 73);
            button8.TabIndex = 8;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = false;
            button8.Click += ClickB;
            // 
            // button9
            // 
            button9.BackColor = Color.LightGray;
            button9.Location = new Point(38, 263);
            button9.Name = "button9";
            button9.Size = new Size(75, 73);
            button9.TabIndex = 7;
            button9.Text = "7";
            button9.UseVisualStyleBackColor = false;
            button9.Click += ClickB;
            // 
            // button10
            // 
            button10.BackColor = Color.LightGray;
            button10.Location = new Point(133, 351);
            button10.Name = "button10";
            button10.Size = new Size(75, 73);
            button10.TabIndex = 10;
            button10.Text = "0";
            button10.UseVisualStyleBackColor = false;
            button10.Click += ClickB;
            // 
            // button12
            // 
            button12.BackColor = Color.Orange;
            button12.Location = new Point(321, 351);
            button12.Name = "button12";
            button12.Size = new Size(75, 73);
            button12.TabIndex = 15;
            button12.Text = "/";
            button12.UseVisualStyleBackColor = false;
            button12.Click += ClickB;
            // 
            // button13
            // 
            button13.BackColor = Color.Orange;
            button13.Location = new Point(321, 263);
            button13.Name = "button13";
            button13.Size = new Size(75, 73);
            button13.TabIndex = 14;
            button13.Text = "*";
            button13.UseVisualStyleBackColor = false;
            button13.Click += ClickB;
            // 
            // button14
            // 
            button14.BackColor = Color.Orange;
            button14.Location = new Point(321, 173);
            button14.Name = "button14";
            button14.Size = new Size(75, 73);
            button14.TabIndex = 13;
            button14.Text = "-";
            button14.UseVisualStyleBackColor = false;
            button14.Click += ClickB;
            // 
            // button15
            // 
            button15.BackColor = Color.Orange;
            button15.Location = new Point(321, 84);
            button15.Name = "button15";
            button15.Size = new Size(75, 73);
            button15.TabIndex = 12;
            button15.Text = "+";
            button15.UseVisualStyleBackColor = false;
            button15.Click += ClickB;
            // 
            // button16
            // 
            button16.BackColor = Color.Orange;
            button16.Location = new Point(38, 351);
            button16.Name = "button16";
            button16.Size = new Size(75, 73);
            button16.TabIndex = 16;
            button16.Text = "AC";
            button16.UseVisualStyleBackColor = false;
            button16.Click += button16_Click;
            // 
            // button11
            // 
            button11.BackColor = Color.Orange;
            button11.Location = new Point(227, 351);
            button11.Name = "button11";
            button11.Size = new Size(75, 73);
            button11.TabIndex = 17;
            button11.Text = "=";
            button11.UseVisualStyleBackColor = false;
            button11.Click += button11_Click;
            // 
            // button17
            // 
            button17.BackColor = Color.Orange;
            button17.Location = new Point(321, 12);
            button17.Name = "button17";
            button17.Size = new Size(75, 54);
            button17.TabIndex = 18;
            button17.Text = "<---";
            button17.UseVisualStyleBackColor = false;
            button17.Click += button17_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(2, 433);
            label1.Name = "label1";
            label1.Size = new Size(80, 15);
            label1.TabIndex = 19;
            label1.Text = "Made by Litsy";
            // 
            // button18
            // 
            button18.BackColor = Color.Orange;
            button18.Location = new Point(504, 129);
            button18.Name = "button18";
            button18.Size = new Size(75, 73);
            button18.TabIndex = 20;
            button18.Text = "Tangens";
            button18.UseVisualStyleBackColor = false;
            button18.Click += ButtonTan;
            // 
            // button19
            // 
            button19.BackColor = Color.Orange;
            button19.Location = new Point(504, 218);
            button19.Name = "button19";
            button19.Size = new Size(75, 73);
            button19.TabIndex = 21;
            button19.Text = "Sinus";
            button19.UseVisualStyleBackColor = false;
            button19.Click += ButtonSin;
            // 
            // button21
            // 
            button21.BackColor = Color.Orange;
            button21.Location = new Point(585, 129);
            button21.Name = "button21";
            button21.Size = new Size(75, 73);
            button21.TabIndex = 23;
            button21.Text = "CoTangens";
            button21.UseVisualStyleBackColor = false;
            button21.Click += ButtonCoTan;
            // 
            // button22
            // 
            button22.BackColor = Color.Orange;
            button22.Location = new Point(585, 218);
            button22.Name = "button22";
            button22.Size = new Size(75, 73);
            button22.TabIndex = 24;
            button22.Text = "Cosinus";
            button22.UseVisualStyleBackColor = false;
            button22.Click += ButtonCos;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            ClientSize = new Size(433, 450);
            Controls.Add(button22);
            Controls.Add(button21);
            Controls.Add(button19);
            Controls.Add(button18);
            Controls.Add(label1);
            Controls.Add(button17);
            Controls.Add(button11);
            Controls.Add(button16);
            Controls.Add(button12);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button10);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button9);
            Controls.Add(button4);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Калькулятор";
            Load += Form1_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button11;
        private Button button17;
        private Label label1;
        private Button button18;
        private Button button19;
        private Button button21;
        private Button button22;
    }
}
